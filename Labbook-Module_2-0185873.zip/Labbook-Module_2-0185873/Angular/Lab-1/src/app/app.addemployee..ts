import { Component } from '@angular/core';
import { setDOM } from '@angular/platform-browser/src/dom/dom_adapter';

@Component({
    selector:'add-emp',


    templateUrl:'app.add.html'
})
export class AddEmployeeComponent{
    empId:any;
    empName:any;
    empSalary:any;
  
    empall:any[]=[{empId:100,empName:"Raj",empSalary:1000.00},
    {empId:101,empName:"Rahul",empSalary:1500.00},
    {empId:102,empName:"Sham",empSalary:2000.00} ];
    
      addEmployee():any{
         this.empall.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary}) ;
         
          
        
       
    }
      deleteEmployee(data:number):any{
        this.empall.splice(data,1); 
       // alert("data deleted.........");
      }
      data:number=null;
      empid:any;
      empname:any;
      empsalary:any;
      updateEmployee(i:number):any{
       this.empid=this.empall[i].empId;
       this.empname=this.empall[i].empName;
       this.empsalary=this.empall[i].empSalary;
        this.data=i;
      }
      updateEmp():any{
        if(this.data!=null)
        this.empall.splice(this.data,1,{empId:this.empid,empName:this.empname,empSalary:this.empsalary})
       
      }
    }
    


