import { Component } from '@angular/core';


@Component({
    selector:'add-emp',


    templateUrl:'app.add.html'
})
export class AddEmployeeComponent{
    empId:number;
    empName:string;
    empSal:number;
    empDep:string;
    empJoinDate:number;
    empall:any[]=[
      {empId:1001,empName:'Rahul',empSal:9000,empDep:'JAVA',empJoinDate:'6/12/2014'},
      {empId:1002,empName:'Vikash',empSal:11000,empDep:'ORAAPS',empJoinDate:'6/12/2017'},
      {empId:1003,empName:'Uma',empSal:12000,empDep:'JAVA',empJoinDate:'6/12/2010'},
      {empId:1004,empName:'Sachin',empSal:11500,empDep:'ORAAPS',empJoinDate:'11/12/2017'},
      {empId:1005,empName:'Amol',empSal:7000,empDep:'.NET',empJoinDate:'1/1/2018'},
      {empId:1006,empName:'Vishal',empSal:17000,empDep:'BI',empJoinDate:'9/12/2012'},
      {empId:1007,empName:'Rajita',empSal:21000,empDep:'BI',empJoinDate:'6/7/2014'},
      {empId:1008,empName:'Neelima',empSal:81000,empDep:'TESTING',empJoinDate:'6/17/2015'},
      {empId:1009,empName:'Daya',empSal:1000,empDep:'TESTING',empJoinDate:'6/17/2016'} ];

    sortById():any{
     
      this.empall=this.empall.sort((a:any,b:any)=>(a.empId-b.empId));
    }
    sortByName():any{
      
      this.empall=this.empall.sort((a:any,b:any)=>(a.empName.localeCompare(b.empName)));
    }
    sortBySalary():any{
      
      this.empall=this.empall.sort((a:any,b:any)=>(a.empSal-b.empSal));
    }
    sortByDep():any{
      
      this.empall=this.empall.sort((a:any,b:any)=>(a.empDep.localeCompare(b.empDep)));
    }
    sortByDate():any{
     
      this.empall=this.empall.sort((a, b) => new Date(b.empJoinDate).getTime() - new Date(a.empJoinDate).getTime());
    
    }
    }
    


