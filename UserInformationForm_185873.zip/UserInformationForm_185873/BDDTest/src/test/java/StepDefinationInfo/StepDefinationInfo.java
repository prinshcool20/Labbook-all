package StepDefinationInfo;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import BeanFeactory.Informationbean;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinationInfo {
	private WebDriver driver;
	private Informationbean bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\prinskum\\Desktop\\Module 4\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'registration' page$")
	public void user_is_on_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.get("D:\\Users\\prinskum\\BDDWorkspace\\BDDTest\\UserInformation.html");
		bean = new Informationbean(driver);
	}

	@When("^get page title$")
	public void get_page_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	    System.out.println("Getting Page Title");
	}

	@Then("^displays 'Page title verified'$")
	public void displays_Page_title_verified() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String actualTitle = driver.getTitle();
		String expectedTitle = "PAN CARD: User Information";
		Assert.assertEquals(expectedTitle,actualTitle);
		System.out.println("Page title verified");
	} 
	
	@When("^user enters invalid applicant name$")
	public void user_enters_invalid_applicant_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the applicant Name'$")
	public void displays_Please_fill_the_applicant_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String exmessage="Please fill the Applicant Name ";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	    //throw new PendingException();
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setApplicantName("Rahul RAj");
		bean.setFirstName("");
		bean.setSubmitButton();
	}
	
	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the First Name ";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the Last Name ";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid father name$")
	public void user_enters_invalid_father_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the father Name'$")
	public void displays_Please_fill_the_father_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//String exmessage="Please fill the DOB";
		//String acmessage=driver.switchTo().alert().getText();
		//Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid date of birth$")
	public void user_enters_invalid_date_of_birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the date of birth'$")
	public void displays_Please_fill_the_date_of_birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the DOB";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid gender$")
	public void user_enters_invalid_gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the gender'$")
	public void displays_Please_fill_the_gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//String exmessage="Please fill Mobile no";
		//String acmessage=driver.switchTo().alert().getText();
		//Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid mobileno$")
	public void user_enters_invalid_mobileno() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the mobileno'$")
	public void displays_Please_fill_the_mobileno() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill Mobile no";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid mailid$")
	public void user_enters_invalid_mailid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("9234567890");
		bean.setMailid("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the maild id'$")
	public void displays_Please_fill_the_maild_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		//String exmessage="Please enter valid mobile no";
		//String acmessage=driver.switchTo().alert().getText();
		//Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid landline$")
	public void user_enters_invalid_landline() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("9234567890");
		bean.setMailid("rahul@gmail.com");
		bean.setLandline("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the landline'$")
	public void displays_Please_fill_the_landline() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//String exmessage="please fill the landline no";
		// acmessage=driver.switchTo().alert().getText();
		//Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
	

	@When("^user enters invalid communication$")
	public void user_enters_invalid_communication() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("9234567890");
		bean.setMailid("rahul@gmail.com");
		bean.setLandline("9123654269");
		bean.setCommunication("");
		bean.setSubmitButton();
	}
	
	@Then("^displays 'Please fill communication'$")
	public void displays_Please_fill_communication() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//String exmessage="Please select the Type of Communication ";
		//String acmessage=driver.switchTo().alert().getText();
		//Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
	@When("^user enters address$")
	public void user_enters_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("9234567890");
		bean.setMailid("rahul@gmail.com");
		bean.setLandline("9123654269");
		bean.setCommunication("Office");
		bean.setAddress("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill address'$")
	public void displays_Please_fill_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="please enter the Addresss";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters valid information$")
	public void user_enters_valid_information() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setApplicantName("Rahul Raj");
		bean.setFirstName("Rahul");
		bean.setLastName("Raj");
		bean.setFatherName("Rajesh");
		bean.setDOB("05-09-1997");
		bean.setGender("Male");
		bean.setMobile("9234567890");
		bean.setMailid("rahul@gmail.com");
		bean.setLandline("9123654269");
		bean.setCommunication("Office");
		bean.setAddress("Capgemini");
		bean.setSubmitButton();
	}

	@Then("^displays 'payment page'$")
	public void displays_payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("D:\\Users\\prinskum\\BDDWorkspace\\BDDTest\\PaymentDetails.html");
	}
}
