package StepDefinationPayment;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import BeanFeactory.Paymentbean;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinationPayment {
	
	private WebDriver driver;
	private Paymentbean bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\prinskum\\Desktop\\Module 4\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'payment' page$")
	public void user_is_on_payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.get("D:\\Users\\prinskum\\BDDWorkspace\\BDDTest\\PaymentDetails.html");
		bean = new Paymentbean(driver);
	}
	
	@When("^get page title$")
	public void get_page_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		 System.out.println("Getting Page Title");
	}

	@Then("^displays 'Page title verified'$")
	public void displays_Page_title_verified() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String actualTitle = driver.getTitle();
		String expectedTitle = "Payment Details";
		Assert.assertEquals(expectedTitle,actualTitle);
		System.out.println("Page title verified");
	}


	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setCardholderName("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the CardHolder Name'$")
	public void displays_Please_fill_the_CardHolder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the Card holder name";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setCardholderName("Rahul Raj");
		bean.setCardNumber("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill the Debit Card Number'$")
	public void displays_Please_fill_the_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the Debit card Number";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
	@When("^user does not enter CVV value$")
	public void user_does_not_enter_CVV_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setCardholderName("Rahul Raj");
		bean.setCardNumber("1235485647856985");
		bean.setCvv("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill CVV number'$")
	public void displays_Please_fill_CVV_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the CVV";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setCardholderName("Rahul Raj");
		bean.setCardNumber("1235485647856985");
		bean.setCvv("654");
		bean.setMonth("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill expiration month";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.setCardholderName("Rahul Raj");
		bean.setCardNumber("1235485647856985");
		bean.setCvv("654");
		bean.setMonth("04");
		bean.setYear("");
		bean.setSubmitButton();
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String exmessage="Please fill the expiration year";
		String acmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(exmessage,acmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		bean.setCardholderName("Rahul Raj");
		bean.setCardNumber("1235485647856985");
		bean.setCvv("654");
		bean.setMonth("04");
		bean.setYear("2256");
		bean.setSubmitButton();
	}
	
	@Then("^display 'Pan Card Registeration successfully$")
	public void display_Pan_Card_Registeration_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("D:\\Users\\prinskum\\BDDWorkspace\\BDDTest\\success.html");
	}


}
