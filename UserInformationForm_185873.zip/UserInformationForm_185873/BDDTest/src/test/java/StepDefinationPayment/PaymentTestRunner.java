package StepDefinationPayment;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/PaymentFeature",glue="StepDefinationPayment",plugin="pretty")
public class PaymentTestRunner {

}
