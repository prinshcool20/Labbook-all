package BeanFeactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Informationbean {
	
	//This is a bean class to initialize web elements by using fields of the UserInformation.html page
	
	WebDriver driver;
	
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement applicantName;
	
	@FindBy(name="txtFName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(name="txtLName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fatherName;
	
	@FindBy(name="txtDOB")
	@CacheLookup
	WebElement DOB;
	
	@FindBy(name="gender")
	@CacheLookup
	WebElement gender;
	
	@FindBy(id="rdbMale")
	@CacheLookup
	WebElement male;
	
	@FindBy(id="rdbFemale")
	@CacheLookup
	WebElement femaile;
	
	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement mailid;
	
	@FindBy(name="txtLLine")
	@CacheLookup
	WebElement landline;
	
	@FindBy(id="rdbOfficeAdd")
	@CacheLookup
	WebElement office;
	
	@FindBy(name="communication")
	@CacheLookup
	WebElement communication;
	
	@FindBy(id="rdbResAddress")
	@CacheLookup
	WebElement Residence;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement address;
	
	

	//using how class
	@FindBy(how=How.ID, using="btnSubmit")
	@CacheLookup
	WebElement submitButton;
	
	public Informationbean(WebDriver driver) {				// to initialize web elements
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//getters and setters
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName.sendKeys(applicantName);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		this.DOB.sendKeys(dOB);
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		this.male.click();
	}

	public WebElement getFemaile() {
		return femaile;
	}

	public void setFemaile() {
		this.femaile.click();
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid.sendKeys(mailid);
	}

	public WebElement getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline.sendKeys(landline);
	}

	public WebElement getOffice() {
		return office;
	}

	public void setOffice() {
		this.office.click();
	}

	public WebElement getResidence() {
		return Residence;
	}

	public void setResidence() {
		this.Residence.click();
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender=driver.findElement(By.id("rdbMale"));
		this.gender.click();
	}

	public WebElement getCommunication() {
		return communication;
	}

	public void setCommunication(String communication) {
		this.communication=driver.findElement(By.id("rdbOfficeAdd"));
		this.communication.click();
	}
	
	
	
}
