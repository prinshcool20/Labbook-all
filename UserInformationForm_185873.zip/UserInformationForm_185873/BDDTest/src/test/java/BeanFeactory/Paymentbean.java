package BeanFeactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Paymentbean {

	//This is a bean class to initialize web elements by using fields of the PaymentDetails.html page
WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement cardholderName;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement cardNumber;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement month;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement year;
	
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement submitButton;
	
	public Paymentbean(WebDriver driver) {				// to initialize web elements
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//getters and setters
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName.sendKeys(cardholderName);
	}

	public WebElement getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber.sendKeys(cardNumber);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}
	
	

}
